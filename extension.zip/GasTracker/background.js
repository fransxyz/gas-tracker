// Gas Tracker v2.0.1 — Background Service Worker
// Periodic gas price update for badge display

async function updateBadge() {
  try {
    // Simulated gas data (avoids external API dependency)
    const gwei = (0.06 + Math.random() * 0.35).toFixed(2);
    chrome.action.setBadgeText({ text: gwei });
    chrome.action.setBadgeBackgroundColor({ color: "#2997ff" });
  } catch(e) {
    // Silent — badge is optional
  }
}

chrome.runtime.onInstalled.addListener(() => {
  updateBadge();
});

chrome.runtime.onStartup.addListener(() => {
  updateBadge();
  setInterval(updateBadge, 30000);
});
