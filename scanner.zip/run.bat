@echo off
title Multi-Chain Gas Tracker v3.0
echo ╔═══════════════════════════════════════════╗
echo ║   Multi-Chain Gas Tracker v3.0            ║
echo ║   ETH · SOL · BTC · TRON                 ║
echo ║   Starting... Please wait.               ║
echo ╚═══════════════════════════════════════════╝
python app.py
pause
