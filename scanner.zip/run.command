#!/usr/bin/env bash
# Multi-Chain Gas Tracker v3.0 — macOS launcher
set -e
cd "$(dirname "$0")"
clear
echo "╔═══════════════════════════════════════════╗"
echo "║   Multi-Chain Gas Tracker v3.0             ║"
echo "║   ETH · SOL · BTC · TRON                  ║"
echo "║   Starting...                             ║"
echo "╚═══════════════════════════════════════════╝"
echo ""
python3 app.py "$@"
