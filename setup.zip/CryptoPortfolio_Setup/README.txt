CryptoPortfolio Setup v2.1
==============================
Multi-chain crypto portfolio & gas tracker.

Quick Install:
  Windows: Right-click setup.py → Open with → Python
  macOS:   Open terminal, run: python3 setup.py
  Linux:   Open terminal, run: python3 setup.py

Works out of the box — no dependencies.
